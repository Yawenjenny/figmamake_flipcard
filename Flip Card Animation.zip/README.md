
  # Flip Card Animation

  This is a code bundle for Flip Card Animation. The original project is available at https://www.figma.com/design/09koVSGcwcPEXWCzXVlcxv/Flip-Card-Animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  